package view;

public enum ChangeMemberOptions {
	changeName,deleteMember,addBoat,deleteBoat, changeBoat,others;
}
