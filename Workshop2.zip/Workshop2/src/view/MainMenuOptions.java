package view;

public enum MainMenuOptions {
		showVerbose, showCompact, addMember, changeMember, quitApp, others;

}

