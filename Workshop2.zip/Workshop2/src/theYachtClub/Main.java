package theYachtClub;

/*
 * Authors: Amelie Löwe and Johan Eriksson for the 1DV607 course
 */
public class Main {
	/*
	 * Main class for the Yachtclub application
	 */

	public static void main(String[] args) {

		Controller controller = new Controller();
		controller.welcomeMessage();// entry-point

	}

}
