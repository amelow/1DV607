# Objektorienterad analys och design med UML
# Coursecode: 1DV607
Workshop 2 instructions
Pre-requisites: 
Java and a Java compiler(I am using Eclipse in this project)
# How to run the program:
1. Download the "Workshop2"- zip file and open this project in the compiler chosen by you.
2. Open the "Main.class".
3. Run the program.
4. Navigate by using the console.




