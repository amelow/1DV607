package model.observer;

public interface IObserver {
	public void infoToObservers();
}
