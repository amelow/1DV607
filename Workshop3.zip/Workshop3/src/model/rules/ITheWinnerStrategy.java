package model.rules;

public interface ITheWinnerStrategy {

	public boolean isWinner(int dealerScore, int playerScore);
}
